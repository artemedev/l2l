﻿namespace l2l_aggregator.Services.GS1ParserService.Models
{
    public enum DataType
    {
        Numeric,
        Alphanumeric,
        NumericText,
        Date
    }
}
